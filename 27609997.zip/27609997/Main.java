package Management;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Main 
{
	private static final PolicyDAO policyDAO = new PolicyDAO();
	private static final TravelerDAO travelerDAO = new TravelerDAO();
	private static final ClaimDAO claimDAO = new ClaimDAO();


	public static void main(String[] args) throws SQLException 
	{
		Policy policy = new Policy();
		Traveler traveler= new Traveler();
		Claim claim = new Claim();

		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("1) policy management");
			System.out.println("2) traveler management");
			System.out.println("3) claim management");
			System.out.println("4) exit");
			System.out.println("Enter your choice : ");
			int choice = sc.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("1) add a policy");
				System.out.println("2) view policy details");
				System.out.println("3) update policy info");
				System.out.println("4) delete the policy");
				System.out.println("Enter your choice : ");
				int choice1 = sc.nextInt();
				if(choice1==1)
				{
					System.out.println("1)Enter policy_number :");
					policy.setPolicy_no(sc.nextInt());
					System.out.println("2)Enter type:");
					policy.setType(sc.next());
					System.out.println("3)Enter coverage_amount:");
					policy.setCoverage_amount(sc.nextInt());
					System.out.println("4)Enter premium_amount:");
					policy.setPremium_amount(sc.nextInt());
					try {
						policyDAO.addPolicy(policy);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				      System.out.println("Policy added successfully.");
					
				}
				if(choice1==2)
				{
					System.out.println("1)Enter policy_id :");
					int policyId =sc.nextInt();
			        Policy policy1 = policyDAO.getPolicy(policyId);
				        if (policy1 != null) {
				            System.out.println("Policy Details:");
				            System.out.println("Policy ID: " + policy1.getPolicy_id());
				            System.out.println("Policy Number: " + policy1.getPolicy_no());
				            System.out.println("Type: " + policy1.getType());
				            System.out.println("Coverage Amount: " + policy1.getCoverage_amount());
				            System.out.println("Premium Amount: " + policy1.getPremium_amount());
				        } else {
				            System.out.println("Policy not found.");
				        }
					
				}
				if(choice1==3)
				{
					System.out.println("1)Enter policy_id :");
					policy.setPolicy_id(sc.nextInt());
					System.out.println("1)Enter new policy_number :");
					policy.setPolicy_no(sc.nextInt());
					System.out.println("2)Enter new type:");
					policy.setType(sc.next());
					System.out.println("3)Enter new coverage_amount:");
					policy.setCoverage_amount(sc.nextInt());
					System.out.println("4)Enter new premium_amount:");
					policy.setPremium_amount(sc.nextInt());
					try {
						policyDAO.updatePolicy(policy);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				      System.out.println("Policy updated successfully.");
					
				}
				if(choice1==4)
				{
					System.out.println("1)Enter policy_id :");
					policy.setPolicy_id(sc.nextInt());
					try
					{
						policyDAO.deletePolicy(policy.getPolicy_id());
						
					}
					catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("Policy deleted successfully.");
				}
				break;
			
			case 2:
				System.out.println("1) Register a new traveler");
				System.out.println("2) View traveler details");
				System.out.println("3) Update traveler information");
				System.out.println("4) Delete a traveler");
				System.out.println("Enter your choice : ");
				int choice2 = sc.nextInt();
				if(choice2==1)
				{
					System.out.println("1)Enter name:");
					traveler.setName(sc.next());
					System.out.println("2)Enter email:");
					traveler.setEmail(sc.next());
					System.out.println("3)Enter phone number:");
					traveler.setPhone_number(sc.next());
					System.out.println("4)Enter address:");
					traveler.setAddress(sc.next());
					try {
						travelerDAO.addTraveler(traveler);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				      System.out.println("Traveler added successfully.");
					
				}
				if(choice2==2)
				{
					System.out.println("1)Enter traveler_id :");
					int traveler_id =sc.nextInt();
			        Traveler traveler1 = travelerDAO.getTraveler(traveler_id);
				        if (traveler1 != null) {
				            System.out.println("Traveler Details:");
				            System.out.println("Traveler ID: " + traveler1.getTraveler_id());
				            System.out.println("Name: " + traveler1.getName());
				            System.out.println("Email: " + traveler1.getEmail());
				            System.out.println("phone number: " + traveler1.getPhone_number());
				            System.out.println("Address: " + traveler1.getAddress());
				        } else {
				            System.out.println("Policy not found.");
				        }
					
					
				}
				if(choice2==3)
				{
					System.out.println("1)Enter traveler_id :");
					traveler.setTraveler_id(sc.nextInt());
					System.out.println("1)Enter name:");
					traveler.setName(sc.next());
					System.out.println("2)Enter email:");
					traveler.setEmail(sc.next());
					System.out.println("3)Enter phone number:");
					traveler.setPhone_number(sc.next());
					System.out.println("4)Enter address:");
					traveler.setAddress(sc.next());
					try {
						travelerDAO.updateTraveler(traveler);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				      System.out.println("traveler updated successfully.");
					
				}
				if(choice2==4)
				{
					System.out.println("1)Enter traveler_id :");
					traveler.setTraveler_id(sc.nextInt());
					try
					{
						travelerDAO.deleteTraveler(traveler.getTraveler_id());
						
					}
					catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("Policy deleted successfully.");
				}
				break;
			case 3:
				System.out.println("1) Submit a new claim");
				System.out.println("2) View claim details");
				System.out.println("3) Update claim information");
				System.out.println("4) Delete a claim");
				System.out.println("Enter your choice : ");
				int choice3 = sc.nextInt();
				if(choice3==1)
				{
					System.out.println("1)Enter POLICY_ID:");
					claim.setPolicy_id(sc.nextInt());
					System.out.println("2)Enter traveler_id:");
					claim.setTraveler_id(sc.nextInt());
					System.out.println("Enter claim date (yyyy-mm-dd): ");
				    String dateInput = sc.next();
				    java.sql.Date sqlDate = null;
				    try {
				        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				        java.util.Date utilDate = sdf.parse(dateInput);
				        sqlDate = new java.sql.Date(utilDate.getTime());
				    } catch (ParseException e) {
				        System.out.println("Invalid date format. Please use yyyy-mm-dd.");
				        return;
				    }
				    claim.setClaim_date(sqlDate);					
				    System.out.println("4)Enter Status (submitted/processed):");
					claim.setStatus(sc.next());
					try {
						claimDAO.addClaim(claim);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				      System.out.println("claim added successfully.");
					
				}
				if(choice3==2)
				{
					System.out.println("1)Enter claim_id :");
					int claim_id =sc.nextInt();
			        Claim claim1 = claimDAO.getClaim(claim_id);
				        if (claim1 != null) {
				            System.out.println("Traveler Details:");
				            System.out.println("claim ID: " + claim1.getClaim_id());
				            System.out.println("policy id: " + claim1.getPolicy_id());
				            System.out.println("traveler id: " + claim1.getTraveler_id());
				            System.out.println("claim_date: " + claim1.getClaim_date());
				            System.out.println("status :" + claim1.getStatus());
				        } else {
				            System.out.println("claim not found.");
				        }
				}
				if(choice3==3)
				{
					System.out.println("1)Enter claim_id :");
					claim.setClaim_id(sc.nextInt());
					System.out.println("1)Enter POLICY_ID:");
					claim.setPolicy_id(sc.nextInt());
					System.out.println("2)Enter traveler_id:");
					claim.setTraveler_id(sc.nextInt());
					 System.out.print("Enter claim date (yyyy-mm-dd): ");
					String dateInput = sc.next();
				    java.sql.Date sqlDate = null;
				    try {
				        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				        java.util.Date utilDate = sdf.parse(dateInput);
				        sqlDate = new java.sql.Date(utilDate.getTime());
				    } catch (ParseException e) {
				        System.out.println("Invalid date format. Please use yyyy-mm-dd.");
				        return;
				    }
				    claim.setClaim_date(sqlDate);
					System.out.println("4)Enter Status (submitted/processed):");
					claim.setStatus(sc.next());
					try {
						claimDAO.updateClaim(claim);
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
				      System.out.println("claim updated successfully.");
					
				}
				if(choice3==4)
				{
					System.out.println("1)Enter claim_id :");
					claim.setClaim_id(sc.nextInt());
					try
					{
						claimDAO.deleteClaim(claim.getClaim_id());
						
					}
					catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("claim deleted successfully.");
				}
				break;
			case 4:
                System.out.println("Exiting the system.");
                return;
                
            default:
                System.out.println("Invalid choice. Please try again.");
			}
		}

	}

}
