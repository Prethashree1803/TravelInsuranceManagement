package Management;
import java.util.*;

public class Claim {

	private int claim_id;
	private int policy_id;
	private int traveler_id;
	private Date claim_date;
	private String status;
	
	
	public int getClaim_id() {
		return claim_id;
	}
	public void setClaim_id(int claim_id) {
		this.claim_id = claim_id;
	}
	public int getPolicy_id() {
		return policy_id;
	}
	public void setPolicy_id(int policy_id) {
		this.policy_id = policy_id;
	}
	public int getTraveler_id() {
		return traveler_id;
	}
	public void setTraveler_id(int traveler_id) {
		this.traveler_id = traveler_id;
	}
	public Date getClaim_date() {
		return claim_date;
	}
	public void setClaim_date(Date claim_date) {
		this.claim_date = claim_date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
