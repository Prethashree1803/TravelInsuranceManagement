package Management;


public class Policy {

	private int policy_id;
	private int policy_no;
	private String type;
	private int coverage_amount;
	private int premium_amount;
	
	public int getPolicy_id() {
		return policy_id;
	}
	public void setPolicy_id(int policy_id) {
		this.policy_id = policy_id;
	}
	public int getPolicy_no() {
		return policy_no;
	}
	public void setPolicy_no(int policy_no) {
		this.policy_no = policy_no;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getCoverage_amount() {
		return coverage_amount;
	}
	public void setCoverage_amount(int coverage_amount) {
		this.coverage_amount = coverage_amount;
	}
	public int getPremium_amount() {
		return premium_amount;
	}
	public void setPremium_amount(int premium_amount) {
		this.premium_amount = premium_amount;
	}
	 
	
	
	

}
