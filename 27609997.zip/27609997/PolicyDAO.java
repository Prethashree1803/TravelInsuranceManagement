package Management;
import java.sql.*;

public class PolicyDAO {
		//DbConnection DbConnection = new DbConnection();
		public void addPolicy(Policy policy) throws SQLException 
		{
	        String query = "INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";
	        try 
	        {
	        	Connection connection = DbConnection.getConnection(); 
	        	PreparedStatement preparedStatement = connection.prepareStatement(query);
	            preparedStatement.setInt(1, policy.getPolicy_no());
	            preparedStatement.setString(2, policy.getType());
	            preparedStatement.setDouble(3, policy.getCoverage_amount());
	            preparedStatement.setDouble(4, policy.getPremium_amount());
	            preparedStatement.executeUpdate();
	        }
	        catch(Exception e)
	        {
	        	System.out.println("connection failed");
	        }
	    }

	    public Policy getPolicy(int policyId)  {
	        String query = "SELECT * FROM Policy WHERE policy_id = ?";
	        try  {
	        	 Connection connection = DbConnection.getConnection();
	             PreparedStatement preparedStatement = connection.prepareStatement(query);
	            preparedStatement.setInt(1, policyId);
	            ResultSet resultSet = preparedStatement.executeQuery();
	            if (resultSet.next()) {
	                Policy policy = new Policy();
	                policy.setPolicy_id(resultSet.getInt("policy_id"));
	                policy.setPolicy_no(resultSet.getInt("policy_number"));
	                policy.setType(resultSet.getString("type"));
	                policy.setCoverage_amount(resultSet.getInt("coverage_amount"));
	                policy.setPremium_amount(resultSet.getInt("premium_amount"));
	                return policy;
	            }
	        }
	        catch(Exception e)
	        {
	        	System.out.println("connection failed");
	        	
	        }
			return null;
	       
	    }

	    public void updatePolicy(Policy policy) throws SQLException {
	        String query = "UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
	        try 
	        {
	        	Connection connection = DbConnection.getConnection();
	            PreparedStatement preparedStatement = connection.prepareStatement(query);
	            preparedStatement.setInt(1, policy.getPolicy_no());
	            preparedStatement.setString(2, policy.getType());
	            preparedStatement.setDouble(3, policy.getCoverage_amount());
	            preparedStatement.setDouble(4, policy.getPremium_amount());
	            preparedStatement.setInt(5, policy.getPolicy_id());
	            preparedStatement.executeUpdate();
	        }
	        catch(Exception e)
	        {
	        	System.out.println("connection failed");
	        }
	    }

	    public void deletePolicy(int policyId) throws SQLException {
	        String query = "DELETE FROM Policy WHERE policy_id = ?";
	        try  
	        {
	        	Connection connection = DbConnection.getConnection();
	            PreparedStatement preparedStatement = connection.prepareStatement(query);
	            preparedStatement.setInt(1, policyId);
	            preparedStatement.executeUpdate();
	        }
	        catch(Exception e)
	        {
	        	System.out.println("connection failed");
	        }
	    }

	

	


}
