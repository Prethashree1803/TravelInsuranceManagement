package Management;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ClaimDAO 
{
	public void addClaim(Claim claim) throws SQLException 
	{
        String query = "INSERT INTO Claim (policy_id, traveler_id, claim_date, status) VALUES (?, ?, ?, ?)";
        try 
        {
        	Connection connection = DbConnection.getConnection(); 
        	PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, claim.getPolicy_id());
            preparedStatement.setInt(2, claim.getTraveler_id());
            preparedStatement.setDate(3, (java.sql.Date) claim.getClaim_date());
            preparedStatement.setString(4, claim.getStatus());
            preparedStatement.executeUpdate();
        }
        catch(Exception e)
        {
        	System.out.println("connection failed");
        }
    }

    public Claim getClaim(int claim_id) throws SQLException {
        String query = "SELECT * FROM claim WHERE claim_id = ?";
        try 
        {
        	Connection connection = DbConnection.getConnection(); 
        	PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, claim_id);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                Claim claim = new Claim();
                claim.setClaim_id(resultSet.getInt("claim_id"));
                claim.setPolicy_id(resultSet.getInt("policy_id"));
                claim.setTraveler_id(resultSet.getInt("traveler_id"));
                claim.setClaim_date(resultSet.getDate("claim_date"));
                claim.setStatus(resultSet.getString("status"));
                return claim;
            }
        }
        catch(Exception e)
        {
        	System.out.println("connection failed");
        }
        return null;
    }

    public void updateClaim(Claim claim) throws SQLException {
        String query = "UPDATE Claim SET policy_id = ?, traveler_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";
        try  
        {
        	Connection connection = DbConnection.getConnection(); 
        	PreparedStatement preparedStatement = connection.prepareStatement(query);
        	preparedStatement.setInt(1, claim.getPolicy_id());
            preparedStatement.setInt(2, claim.getTraveler_id());
            preparedStatement.setDate(3, (java.sql.Date) claim.getClaim_date());
            preparedStatement.setString(4, claim.getStatus());
            preparedStatement.setInt(5, claim.getClaim_id());
            preparedStatement.executeUpdate();
            
        }
        catch(Exception e)
        {
        	System.out.println("connection failed");
        }
    }

    public void deleteClaim(int claim_id) throws SQLException {
        String query = "DELETE FROM Claim WHERE claim_id = ?";
        try 
        {
        	Connection connection = DbConnection.getConnection(); 
        	PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, claim_id);
            preparedStatement.executeUpdate();
        }
        catch(Exception e)
        {
        	System.out.println("connection failed");
        }
    }
}
